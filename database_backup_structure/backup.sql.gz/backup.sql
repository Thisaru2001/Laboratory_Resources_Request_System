CREATE DATABASE  IF NOT EXISTS `mdb` /*!40100 DEFAULT CHARACTER SET utf8mb4 COLLATE utf8mb4_0900_ai_ci */ /*!80016 DEFAULT ENCRYPTION='N' */;
USE `mdb`;
-- MySQL dump 10.13  Distrib 8.4.5, for Win64 (x86_64)
--
-- Host: 127.0.0.1    Database: mdb
-- ------------------------------------------------------
-- Server version	8.4.5

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!50503 SET NAMES utf8 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

--
-- Table structure for table `book_equipment`
--

DROP TABLE IF EXISTS `book_equipment`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `book_equipment` (
  `id` int NOT NULL AUTO_INCREMENT,
  `book_qty` int DEFAULT NULL,
  `reservation_id` int NOT NULL,
  `equipment_id` int NOT NULL,
  PRIMARY KEY (`id`),
  KEY `fk_book_equipment_reservation1_idx` (`reservation_id`),
  KEY `fk_book_equipment_equipment1_idx` (`equipment_id`),
  CONSTRAINT `fk_book_equipment_equipment1` FOREIGN KEY (`equipment_id`) REFERENCES `equipment` (`id`),
  CONSTRAINT `fk_book_equipment_reservation1` FOREIGN KEY (`reservation_id`) REFERENCES `reservation` (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=63 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `book_equipment`
--

LOCK TABLES `book_equipment` WRITE;
/*!40000 ALTER TABLE `book_equipment` DISABLE KEYS */;
/*!40000 ALTER TABLE `book_equipment` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `broken`
--

DROP TABLE IF EXISTS `broken`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `broken` (
  `id` int NOT NULL AUTO_INCREMENT,
  `broken_qty` int DEFAULT NULL,
  `equipment_id` int NOT NULL,
  `is_technical_officer` tinyint(1) DEFAULT NULL,
  `is_hod` tinyint(1) DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `fk_broken_equipment1_idx` (`equipment_id`),
  CONSTRAINT `fk_broken_equipment1` FOREIGN KEY (`equipment_id`) REFERENCES `equipment` (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=17 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `broken`
--

LOCK TABLES `broken` WRITE;
/*!40000 ALTER TABLE `broken` DISABLE KEYS */;
/*!40000 ALTER TABLE `broken` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `equipment`
--

DROP TABLE IF EXISTS `equipment`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `equipment` (
  `id` int NOT NULL AUTO_INCREMENT,
  `code` varchar(45) DEFAULT NULL,
  `name` varchar(100) DEFAULT NULL,
  `total_qty` int DEFAULT NULL,
  `simultaneous_users` int DEFAULT NULL,
  `sterilization_required` enum('YES','NO') DEFAULT NULL,
  `reservation_required` enum('YES','NO') DEFAULT NULL,
  `added_datatime` datetime DEFAULT NULL,
  `description` text,
  `is_hod_checked` tinyint(1) DEFAULT NULL,
  `updated_details_datetime` datetime DEFAULT NULL,
  `image_path` text,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=310 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `equipment`
--

LOCK TABLES `equipment` WRITE;
/*!40000 ALTER TABLE `equipment` DISABLE KEYS */;
INSERT INTO `equipment` VALUES (210,'EQ0001','advanced microscope with photograph attachment camera',1,1,'NO','YES','2026-03-23 09:38:37','An advanced microscope with a photographic attachment camera is a high-precision instrument used to observe very small objects in great detail while also capturing images or videos of the observed specimens. It is equipped with powerful lenses that provide high magnification and resolution, allowing users to study cells, tissues, and microorganisms clearly. The attached digital camera enables real-time image capture, which can be displayed on a computer or screen and stored for future use. This type of microscope is widely used in scientific research, medical laboratories, education, and industrial inspection because it allows accurate observation, easy documentation, and detailed analysis of microscopic structures.',1,'2026-03-24 07:08:14','assets/equipment_images/eq_69c0bcc552e929.94338378.jpg'),(211,'EQ0002','Advanced Microscope with Photograph attachment Camera',1,1,'NO','YES','2026-03-23 17:22:48','Advanced microscope with camera attachment for photography',1,'2026-03-24 07:09:49','assets/equipment_images/eq_69c1eb65c7e678.55172384.jpg'),(213,'EQ0004','Anaerobic Chamber',1,2,'NO','YES','2026-03-23 17:22:48','Chamber for anaerobic work',1,'2026-03-23 17:22:48',NULL),(214,'EQ0005','Anaerobic jar',6,6,'YES','YES','2026-03-23 17:22:48','Jars for anaerobic culture',1,'2026-03-23 17:22:48',NULL),(215,'EQ0006','Autoclave – Front Loading',1,1,'NO','YES','2026-03-23 17:22:48','Front loading autoclave for sterilization',1,'2026-03-23 17:22:48',NULL),(216,'EQ0007','Autoclave - Portable',2,1,'NO','YES','2026-03-23 17:22:48','Portable autoclave units',1,'2026-03-23 17:22:48',NULL),(217,'EQ0008','Autoclave -Vertical',3,1,'NO','YES','2026-03-23 17:22:48','Vertical autoclave units',1,'2026-03-23 17:22:48',NULL),(218,'EQ0009','Balance - Electronic',5,1,'NO','YES','2026-03-23 17:22:48','Electronic balances',1,'2026-03-23 17:22:48',NULL),(220,'EQ0011','Balance -Analytical',2,1,'NO','YES','2026-03-23 17:22:48','Analytical balances for precise measurements',1,'2026-03-23 17:22:48',NULL),(222,'EQ0013','Biofuge \"Heamo\"',1,1,'NO','YES','2026-03-23 17:22:48','Biofuge centrifuge',1,'2026-03-23 17:22:48',NULL),(223,'EQ0014','Blender - Electric',1,1,'NO','YES','2026-03-23 17:22:48','Electric blender',1,'2026-03-23 17:22:48',NULL),(224,'EQ0015','Blowpipe',1,1,'NO','YES','2026-03-23 17:22:48','Blowpipe equipment',1,'2026-03-23 17:22:48',NULL),(225,'EQ0016','BOD Trak Apparatus',1,1,'NO','YES','2026-03-23 17:22:48','BOD Trak apparatus for biochemical oxygen demand',1,'2026-03-23 17:22:48',NULL),(230,'EQ0021','Centrifuge',5,1,'NO','YES','2026-03-23 17:22:48','Centrifuge units',1,'2026-03-23 17:22:48',NULL),(231,'EQ0022','Circulator Reservoir Heating',1,1,'NO','YES','2026-03-23 17:22:48','Heating circulator reservoir',1,'2026-03-23 17:22:48',NULL),(232,'EQ0023','Colony Counter',1,1,'NO','YES','2026-03-23 17:22:48','Colony counter for microbiology',1,'2026-03-23 17:22:48',NULL),(235,'EQ0026','Deep Freezer',1,1,'NO','YES','2026-03-23 17:22:48','Deep freezer unit',1,'2026-03-23 17:22:48',NULL),(236,'EQ0027','Deionizer',1,1,'NO','YES','2026-03-23 17:22:48','Water deionizer',1,'2026-03-23 17:22:48',NULL),(237,'EQ0028','Dewer Flask',1,1,'NO','YES','2026-03-23 17:22:48','Dewer flask for cryogenic storage',1,'2026-03-23 17:22:48',NULL),(238,'EQ0029','Disintegrator- Soniprep',1,1,'NO','YES','2026-03-23 17:22:48','Soniprep disintegrator',1,'2026-03-23 17:22:48',NULL),(240,'EQ0031','Electrophoresis Equipment',1,2,'NO','YES','2026-03-23 17:22:48','Electrophoresis equipment',1,'2026-03-23 17:22:48',NULL),(241,'EQ0032','Elisa Reader',2,1,'NO','YES','2026-03-23 17:22:48','ELISA plate readers',1,'2026-03-23 17:22:48',NULL),(244,'EQ0035','Fermentation System \"Modular\" BIO-FLOW 110',1,1,'NO','YES','2026-03-23 17:22:48','Modular fermentation system BIO-FLOW 110',1,'2026-03-23 17:22:48',NULL),(245,'EQ0036','Fermentation System BIO FLOW 115',1,1,'NO','YES','2026-03-23 17:22:48','BIO FLOW 115 fermentation system',1,'2026-03-23 17:22:48',NULL),(247,'EQ0038','Freeze Dryer \"EDWARDS\"',1,1,'NO','YES','2026-03-23 17:22:48','Edwards freeze dryer',1,'2026-03-23 17:22:48',NULL),(248,'EQ0039','Freezer -86 0C Ultra Low-Temperature',2,1,'NO','YES','2026-03-23 17:22:48','-86°C ultra-low temperature freezers',1,'2026-03-23 17:22:48',NULL),(249,'EQ0040','Freezer Dryer \"CHRIST\"',1,1,'NO','YES','2026-03-23 17:22:48','Christ brand freeze dryer',1,'2026-03-23 17:22:48',NULL),(250,'EQ0041','Fume Hood',1,1,'NO','YES','2026-03-23 17:22:48','Fume hood for chemical work',1,'2026-03-23 17:22:48',NULL),(251,'EQ0042','GEL-DOC-EZ Imaging System',1,1,'NO','YES','2026-03-23 17:22:48','Gel documentation imaging system',1,'2026-03-23 17:22:48',NULL),(252,'EQ0043','Heating Block',1,2,'NO','YES','2026-03-23 17:22:48','Heating block unit',1,'2026-03-23 17:22:48',NULL),(253,'EQ0044','Heating Mantle',3,3,'NO','YES','2026-03-23 17:22:48','Heating mantles',1,'2026-03-23 17:22:48',NULL),(254,'EQ0045','Hot Plate - Stirrer',7,7,'NO','YES','2026-03-23 17:22:48','Hot plate stirrers',1,'2026-03-23 17:22:48',NULL),(255,'EQ0046','Incubator - Biological',8,8,'NO','YES','2026-03-23 17:22:48','Biological incubators',1,'2026-03-23 17:22:48',NULL),(257,'EQ0048','Incubator - Cooling',1,1,'NO','YES','2026-03-23 17:22:48','Cooling incubator',1,'2026-03-23 17:22:48',NULL),(258,'EQ0049','Incubator Shaker - Environmental',2,2,'NO','YES','2026-03-23 17:22:48','Environmental incubator shakers',1,'2026-03-23 17:22:48',NULL),(261,'EQ0052','Kjeldahl System',1,1,'NO','YES','2026-03-23 17:22:48','Kjeldahl system for protein analysis',1,'2026-03-23 17:22:48',NULL),(262,'EQ0053','Koch Sterilizer',1,1,'NO','YES','2026-03-23 17:22:48','Koch sterilizer',1,'2026-03-23 17:22:48',NULL),(263,'EQ0054','Laminar Flow',1,1,'NO','YES','2026-03-23 17:22:48','Laminar flow hood',1,'2026-03-23 17:22:48',NULL),(264,'EQ0055','Lovibond Comparator',1,1,'NO','YES','2026-03-23 17:22:48','Lovibond comparator for color analysis',1,'2026-03-23 17:22:48',NULL),(266,'EQ0057','Microplate Reader',1,1,'NO','YES','2026-03-23 17:22:48','Microplate reader',1,'2026-03-23 17:22:48',NULL),(267,'EQ0058','Micropulser Electroporator',1,1,'NO','YES','2026-03-23 17:22:48','Electroporator',1,'2026-03-23 17:22:48',NULL),(270,'EQ0061','Microscopes',144,1,'NO','YES','2026-03-23 17:22:48','Standard microscopes',1,'2026-03-23 17:22:48',NULL),(271,'EQ0062','Microscopes CHS-213E',2,1,'NO','YES','2026-03-23 17:22:48','CHS-213E microscopes',1,'2026-03-23 17:22:48',NULL),(272,'EQ0063','Microwave Oven',1,1,'NO','NO','2026-03-23 17:22:48','Microwave oven',1,'2026-03-23 17:22:48',NULL),(273,'EQ0064','Oven',5,5,'NO','YES','2026-03-23 17:22:48','Laboratory ovens',1,'2026-03-23 17:22:48',NULL),(274,'EQ0065','Paper Cutter',1,1,'NO','NO','2026-03-23 17:22:48','Paper cutter',1,'2026-03-23 17:22:48',NULL),(275,'EQ0066','PCR Machine',1,1,'NO','YES','2026-03-23 17:22:48','PCR thermal cycler',1,'2026-03-23 17:22:48',NULL),(276,'EQ0067','Peristaltic Pump',1,1,'NO','YES','2026-03-23 17:22:48','Peristaltic pump',1,'2026-03-23 17:22:48',NULL),(277,'EQ0068','Petri-dish Sterilizing Case',35,35,'YES','NO','2026-03-23 17:22:48','Cases for sterilizing petri dishes',1,'2026-03-23 17:22:48',NULL),(278,'EQ0069','pH/mV Meter',3,3,'NO','YES','2026-03-23 17:22:48','pH and mV meters',1,'2026-03-23 17:22:48',NULL),(280,'EQ0071','Pipette Rinsing Set',1,1,'NO','NO','2026-03-23 17:22:48','Pipette rinsing equipment',1,'2026-03-23 17:22:48',NULL),(281,'EQ0072','Pipette Sterilizing Case',16,16,'YES','NO','2026-03-23 17:22:48','Cases for sterilizing pipettes',1,'2026-03-23 17:22:48',NULL),(282,'EQ0073','Polythene Sealer',1,1,'NO','NO','2026-03-23 17:22:48','Polythene sealer',1,'2026-03-23 17:22:48',NULL),(283,'EQ0074','Pressure Cooker',2,2,'NO','YES','2026-03-23 17:22:48','Pressure cookers',1,'2026-03-23 17:22:48',NULL),(287,'EQ0078','Refrigerator',13,13,'NO','NO','2026-03-23 17:22:48','Standard refrigerators',1,'2026-03-23 17:22:48',NULL),(288,'EQ0079','Refrigerator -Pharmaceutical',3,3,'NO','YES','2026-03-23 17:22:48','Pharmaceutical-grade refrigerators',1,'2026-03-23 17:22:48',NULL),(290,'EQ0081','Rotary Evaporator',1,1,'NO','YES','2026-03-23 17:22:48','Rotary evaporator',1,'2026-03-23 17:22:48',NULL),(291,'EQ0082','Safety Cabinet - Biological',1,1,'NO','YES','2026-03-23 17:22:48','Biological safety cabinet',1,'2026-03-23 17:22:48',NULL),(293,'EQ0084','Shaker',4,4,'NO','YES','2026-03-23 17:22:48','Laboratory shakers',1,'2026-03-23 17:22:48',NULL),(294,'EQ0085','Shaker – Water-Bath',3,3,'NO','YES','2026-03-23 17:22:48','Water bath shakers',1,'2026-03-23 17:22:48',NULL),(295,'EQ0086','Stomacher',1,1,'NO','YES','2026-03-23 17:22:48','Stomacher for sample homogenization',1,'2026-03-23 17:22:48',NULL),(296,'EQ0087','Stop clock',5,5,'NO','NO','2026-03-23 17:22:48','Stop clocks',1,'2026-03-23 17:22:48',NULL),(297,'EQ0088','Stopwatch',7,7,'NO','NO','2026-03-23 17:22:48','Stopwatches',1,'2026-03-23 17:22:48',NULL),(300,'EQ0091','Ultrasonic Cleaner',1,1,'NO','YES','2026-03-23 17:22:48','Ultrasonic cleaner',1,'2026-03-23 17:22:48',NULL),(303,'EQ0094','Vacuum Pump',1,1,'NO','YES','2026-03-23 17:22:48','Vacuum pump',1,'2026-03-23 17:22:48',NULL),(304,'EQ0095','Vortex Mixer',4,4,'NO','YES','2026-03-23 17:22:48','Vortex mixers',1,'2026-03-23 17:22:48',NULL),(306,'EQ0097','Water Purification System',1,1,'NO','YES','2026-03-23 17:22:48','Water purification system',1,'2026-03-23 17:22:48',NULL),(307,'EQ0098','Water Still',3,3,'NO','YES','2026-03-23 17:22:48','Water distillation units',1,'2026-03-23 17:22:48',NULL),(308,'EQ0099','Wide Mini Sub Cell GT System',1,1,'NO','YES','2026-03-23 17:22:48','Wide mini sub cell GT electrophoresis system',1,'2026-03-23 17:22:48',NULL);
/*!40000 ALTER TABLE `equipment` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `equipment_has_location`
--

DROP TABLE IF EXISTS `equipment_has_location`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `equipment_has_location` (
  `id` int NOT NULL AUTO_INCREMENT,
  `equipment_id` int DEFAULT NULL,
  `location_id` int DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `fk_equipment_has_location_location1_idx` (`location_id`),
  KEY `fk_equipment_has_location_equipment1_idx` (`equipment_id`),
  CONSTRAINT `fk_equipment_has_location_equipment1` FOREIGN KEY (`equipment_id`) REFERENCES `equipment` (`id`),
  CONSTRAINT `fk_equipment_has_location_location1` FOREIGN KEY (`location_id`) REFERENCES `location` (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=4 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `equipment_has_location`
--

LOCK TABLES `equipment_has_location` WRITE;
/*!40000 ALTER TABLE `equipment_has_location` DISABLE KEYS */;
/*!40000 ALTER TABLE `equipment_has_location` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `lab_user`
--

DROP TABLE IF EXISTS `lab_user`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `lab_user` (
  `id` int NOT NULL AUTO_INCREMENT,
  `who_approved` int DEFAULT NULL,
  `first_name` varchar(45) DEFAULT NULL,
  `last_name` varchar(45) DEFAULT NULL,
  `university_id` varchar(45) DEFAULT NULL,
  `email` varchar(100) DEFAULT NULL,
  `mobile` varchar(20) DEFAULT NULL,
  `password_user` text,
  `img_path` text,
  `join_datetime` datetime DEFAULT NULL,
  `approved_datetime` datetime DEFAULT NULL,
  `verification_code` varchar(8) DEFAULT NULL,
  `remember_token` text,
  `details_updated_datetime` datetime DEFAULT NULL,
  `status` tinyint(1) DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `fk_lab_user_lab_user1_idx` (`who_approved`),
  CONSTRAINT `fk_lab_user_lab_user1` FOREIGN KEY (`who_approved`) REFERENCES `lab_user` (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=22 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `lab_user`
--

LOCK TABLES `lab_user` WRITE;
/*!40000 ALTER TABLE `lab_user` DISABLE KEYS */;
INSERT INTO `lab_user` VALUES (1,1,'Anuradhi','Upeksha','HOD','hod@gmail.com','0711234567','$2y$10$mkOJmKjxlFEkK4MesmSBSOgwPiGMkXhpHPuec4JQvEETu5lmV3bQ2','hod_1_1774244361.webp','2026-03-23 14:45:26','2026-03-23 14:46:26','000000','$2y$10$.9dISYKpoDq/NtZQOKbyj.LZKpPvoEZI6mTAzCmgXMxi81yy3xMCG','2026-03-10 14:31:40',1),(18,1,'Kumar','dilshan','SUP001','sup@gmail.com','0712345678','$2y$10$HM7nL7KzZQ3s4.07V8GH1.hYhy.LRJQ8ubEqq5nHNTfG6fN6oMZZO','assets/profile_images/69c105eb67b3a_785b1c3315ca940d.jpg','2026-03-23 14:50:43','2026-03-23 14:53:14','000000','$2y$10$hIQWpdkoOlNEQgQzaa8LCunMviT0QyP7N1kVOKZFrUh2UoElMbPq.','2026-03-10 14:31:40',1),(19,1,'Kumar','Perera','TO001','to1@example.com','0712345041','$2y$10$KoEfUkQqifT9YCHVy9i11u7pSSMHb3Pin9EvTbxvST2pJC1HQudfK','assets/profile_images/69c106de794c4_79cbfffd05c4c9de.jpg','2026-03-23 14:54:46','2026-03-23 14:57:39','000000','$2y$10$iKF2PRTLX2YpyovqvuhCYuwATLGdmJsJpBU3JB9FceZ2MvYBtck7u','2026-03-10 14:31:40',1),(20,1,'Kumar','Perera','TO002','to2t@example.com','0791245096','$2y$10$BjWoIbMi7d0xwtY0iAghkuAGj0.x/u9CIfvgCgnXwIUSmpEaOZR56','assets/profile_images/69c1076d53a65_ca135accf2a6f54b.jpg','2026-03-23 14:57:09','2026-03-24 07:34:41','000000','$2y$10$7Hh693/EOCxG.DK14yVPvOrHpDqPLBUgXjkFCH5mIjZdBc3l4wuby','2026-03-10 14:31:40',1),(21,18,'Kumar','Perera','STU001','stu@gmail.com','0791234567','$2y$10$QnlPqK/m85qLcp7PNZBZSOoXdAgf5lq3hxikD5wqRi//m0Oi/79Ti','assets/profile_images/69c107f5724c3_3a5a9cd92f8da6d7.jpg','2026-03-23 14:59:25','2026-03-23 15:06:32','000000','$2y$10$sAYq383f6hMRBnLwmuiwb.TnI2J56.Dn1lDZBApb9CWZZjM5uywzK','2026-03-10 14:31:40',1);
/*!40000 ALTER TABLE `lab_user` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `lab_user_has_role`
--

DROP TABLE IF EXISTS `lab_user_has_role`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `lab_user_has_role` (
  `lab_user_id` int NOT NULL,
  `role_id` int NOT NULL,
  PRIMARY KEY (`lab_user_id`,`role_id`),
  KEY `fk_lab_user_has_role_role1_idx` (`role_id`),
  KEY `fk_lab_user_has_role_lab_user1_idx` (`lab_user_id`),
  CONSTRAINT `fk_lab_user_has_role_lab_user1` FOREIGN KEY (`lab_user_id`) REFERENCES `lab_user` (`id`),
  CONSTRAINT `fk_lab_user_has_role_role1` FOREIGN KEY (`role_id`) REFERENCES `role` (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `lab_user_has_role`
--

LOCK TABLES `lab_user_has_role` WRITE;
/*!40000 ALTER TABLE `lab_user_has_role` DISABLE KEYS */;
INSERT INTO `lab_user_has_role` VALUES (21,1),(18,2),(19,3),(20,3),(1,4);
/*!40000 ALTER TABLE `lab_user_has_role` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `location`
--

DROP TABLE IF EXISTS `location`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `location` (
  `id` int NOT NULL AUTO_INCREMENT,
  `location` varchar(50) DEFAULT NULL,
  `is_room` tinyint(1) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=19 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `location`
--

LOCK TABLES `location` WRITE;
/*!40000 ALTER TABLE `location` DISABLE KEYS */;
INSERT INTO `location` VALUES (13,'A12-001',NULL),(14,'A12-004',NULL),(15,'A12-006',NULL),(16,'A11-101 (Special Student Lab)',NULL),(17,'A11-108 (Instrument Lab)',NULL),(18,'A05-002 (Teaching Lab)',NULL);
/*!40000 ALTER TABLE `location` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `notification`
--

DROP TABLE IF EXISTS `notification`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `notification` (
  `id` int NOT NULL AUTO_INCREMENT,
  `description` text,
  `created_datetime` datetime DEFAULT NULL,
  `owner_of_notification` int NOT NULL,
  `status` enum('unread','read') DEFAULT 'unread',
  `need_approval` tinyint(1) DEFAULT '0',
  PRIMARY KEY (`id`),
  KEY `fk_notification_lab_user1_idx` (`owner_of_notification`),
  CONSTRAINT `fk_notification_lab_user1` FOREIGN KEY (`owner_of_notification`) REFERENCES `lab_user` (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=166 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `notification`
--

LOCK TABLES `notification` WRITE;
/*!40000 ALTER TABLE `notification` DISABLE KEYS */;
/*!40000 ALTER TABLE `notification` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `practical_finished_hod_notify_and_approval`
--

DROP TABLE IF EXISTS `practical_finished_hod_notify_and_approval`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `practical_finished_hod_notify_and_approval` (
  `id` int NOT NULL AUTO_INCREMENT,
  `description` text,
  `status` enum('read','unread') DEFAULT NULL,
  `is_approved` tinyint(1) DEFAULT NULL,
  `practical_finished_logbook_id` int DEFAULT NULL,
  `rejection_reason` text,
  `approved_or_rejected_datetime` datetime DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `fk_practical_finished_hod_notify_and_approval_practical_fin_idx` (`practical_finished_logbook_id`),
  CONSTRAINT `fk_practical_finished_hod_notify_and_approval_practical_finis1` FOREIGN KEY (`practical_finished_logbook_id`) REFERENCES `practical_finished_logbook` (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `practical_finished_hod_notify_and_approval`
--

LOCK TABLES `practical_finished_hod_notify_and_approval` WRITE;
/*!40000 ALTER TABLE `practical_finished_hod_notify_and_approval` DISABLE KEYS */;
/*!40000 ALTER TABLE `practical_finished_hod_notify_and_approval` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `practical_finished_logbook`
--

DROP TABLE IF EXISTS `practical_finished_logbook`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `practical_finished_logbook` (
  `id` int NOT NULL AUTO_INCREMENT,
  `reservation_id` int DEFAULT NULL,
  `student_id` int DEFAULT NULL,
  `supervisor_id` int DEFAULT NULL,
  `who_technicalOfficer_id` int DEFAULT NULL,
  `any_comment` text,
  `img_path1` text,
  `img_path2` text,
  `img_path3` text,
  `img_path4` text,
  `datetime` datetime DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `fk_practical_finished_logbook_reservation1_idx` (`reservation_id`),
  KEY `fk_practical_finished_logbook_lab_user1_idx` (`student_id`),
  KEY `fk_practical_finished_logbook_lab_user2_idx` (`supervisor_id`),
  KEY `fk_practical_finished_logbook_lab_user3_idx` (`who_technicalOfficer_id`),
  CONSTRAINT `fk_practical_finished_logbook_lab_user1` FOREIGN KEY (`student_id`) REFERENCES `lab_user` (`id`),
  CONSTRAINT `fk_practical_finished_logbook_lab_user2` FOREIGN KEY (`supervisor_id`) REFERENCES `lab_user` (`id`),
  CONSTRAINT `fk_practical_finished_logbook_lab_user3` FOREIGN KEY (`who_technicalOfficer_id`) REFERENCES `lab_user` (`id`),
  CONSTRAINT `fk_practical_finished_logbook_reservation1` FOREIGN KEY (`reservation_id`) REFERENCES `reservation` (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=40 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `practical_finished_logbook`
--

LOCK TABLES `practical_finished_logbook` WRITE;
/*!40000 ALTER TABLE `practical_finished_logbook` DISABLE KEYS */;
/*!40000 ALTER TABLE `practical_finished_logbook` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `practical_finished_supervisor_notify_and_approval`
--

DROP TABLE IF EXISTS `practical_finished_supervisor_notify_and_approval`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `practical_finished_supervisor_notify_and_approval` (
  `id` int NOT NULL AUTO_INCREMENT,
  `description` longtext CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci,
  `status` varchar(50) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT 'unread',
  `is_approved` tinyint(1) DEFAULT NULL COMMENT '1=approved, 0=rejected, NULL=pending',
  `practical_finished_logbook_id` int NOT NULL,
  `rejection_reason` longtext CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci,
  `approved_or_rejected_datetime` datetime DEFAULT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `unique_logbook_supervisor` (`practical_finished_logbook_id`),
  CONSTRAINT `practical_finished_supervisor_notify_and_approval_ibfk_1` FOREIGN KEY (`practical_finished_logbook_id`) REFERENCES `practical_finished_logbook` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `practical_finished_supervisor_notify_and_approval`
--

LOCK TABLES `practical_finished_supervisor_notify_and_approval` WRITE;
/*!40000 ALTER TABLE `practical_finished_supervisor_notify_and_approval` DISABLE KEYS */;
/*!40000 ALTER TABLE `practical_finished_supervisor_notify_and_approval` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `practical_finished_technicalofficer_notify_and_approval`
--

DROP TABLE IF EXISTS `practical_finished_technicalofficer_notify_and_approval`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `practical_finished_technicalofficer_notify_and_approval` (
  `id` int NOT NULL AUTO_INCREMENT,
  `description` text,
  `status` enum('read','unread') DEFAULT NULL,
  `is_approved` tinyint(1) DEFAULT NULL,
  `practical_finished_logbook_id` int DEFAULT NULL,
  `rejection_reason` text,
  `approved_or_rejected_datetime` datetime DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `fk_practical_finished_hod_notify_and_approval_practical_fin_idx` (`practical_finished_logbook_id`),
  CONSTRAINT `fk_practical_finished_hod_notify_and_approval_practical_finis10` FOREIGN KEY (`practical_finished_logbook_id`) REFERENCES `practical_finished_logbook` (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `practical_finished_technicalofficer_notify_and_approval`
--

LOCK TABLES `practical_finished_technicalofficer_notify_and_approval` WRITE;
/*!40000 ALTER TABLE `practical_finished_technicalofficer_notify_and_approval` DISABLE KEYS */;
/*!40000 ALTER TABLE `practical_finished_technicalofficer_notify_and_approval` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `reject_reason`
--

DROP TABLE IF EXISTS `reject_reason`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `reject_reason` (
  `id` int NOT NULL AUTO_INCREMENT,
  `reason` text,
  `reservation_id` int NOT NULL,
  `who_rejected` int NOT NULL,
  PRIMARY KEY (`id`),
  KEY `fk_reject_reason_reservation1_idx` (`reservation_id`),
  KEY `fk_reject_reason_lab_user1_idx` (`who_rejected`),
  CONSTRAINT `fk_reject_reason_lab_user1` FOREIGN KEY (`who_rejected`) REFERENCES `lab_user` (`id`),
  CONSTRAINT `fk_reject_reason_reservation1` FOREIGN KEY (`reservation_id`) REFERENCES `reservation` (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=5 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `reject_reason`
--

LOCK TABLES `reject_reason` WRITE;
/*!40000 ALTER TABLE `reject_reason` DISABLE KEYS */;
/*!40000 ALTER TABLE `reject_reason` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `repair`
--

DROP TABLE IF EXISTS `repair`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `repair` (
  `id` int NOT NULL AUTO_INCREMENT,
  `repair_qty` int DEFAULT NULL,
  `equipment_id` int NOT NULL,
  `is_technical_officer` tinyint(1) DEFAULT NULL,
  `is_hod` tinyint(1) DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `fk_repair_equipment1_idx` (`equipment_id`),
  CONSTRAINT `fk_repair_equipment1` FOREIGN KEY (`equipment_id`) REFERENCES `equipment` (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=18 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `repair`
--

LOCK TABLES `repair` WRITE;
/*!40000 ALTER TABLE `repair` DISABLE KEYS */;
/*!40000 ALTER TABLE `repair` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `reservation`
--

DROP TABLE IF EXISTS `reservation`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `reservation` (
  `id` int NOT NULL AUTO_INCREMENT,
  `reservation_id` varchar(20) DEFAULT NULL,
  `created_datetime` datetime DEFAULT NULL,
  `student_id` int DEFAULT NULL,
  `supervisor_id` int DEFAULT NULL,
  `technical_officer_id` int DEFAULT NULL,
  `location_id` int NOT NULL,
  `request_date` date DEFAULT NULL,
  `continue_days` int NOT NULL DEFAULT '1',
  `comment` text,
  `updated_details_by_student` datetime DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `fk_reservation_lab_user1_idx` (`student_id`),
  KEY `fk_reservation_lab_user2_idx` (`supervisor_id`),
  KEY `fk_reservation_lab_user3_idx` (`technical_officer_id`),
  KEY `fk_reservation_location1_idx` (`location_id`),
  CONSTRAINT `fk_reservation_lab_user1` FOREIGN KEY (`student_id`) REFERENCES `lab_user` (`id`),
  CONSTRAINT `fk_reservation_lab_user2` FOREIGN KEY (`supervisor_id`) REFERENCES `lab_user` (`id`),
  CONSTRAINT `fk_reservation_lab_user3` FOREIGN KEY (`technical_officer_id`) REFERENCES `lab_user` (`id`),
  CONSTRAINT `fk_reservation_location1` FOREIGN KEY (`location_id`) REFERENCES `location` (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=38 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `reservation`
--

LOCK TABLES `reservation` WRITE;
/*!40000 ALTER TABLE `reservation` DISABLE KEYS */;
/*!40000 ALTER TABLE `reservation` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `role`
--

DROP TABLE IF EXISTS `role`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `role` (
  `id` int NOT NULL AUTO_INCREMENT,
  `role` varchar(45) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=6 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `role`
--

LOCK TABLES `role` WRITE;
/*!40000 ALTER TABLE `role` DISABLE KEYS */;
INSERT INTO `role` VALUES (1,'student'),(2,'supervisor'),(3,'technical_officer'),(4,'hod'),(5,'admin');
/*!40000 ALTER TABLE `role` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `supervisor_assigned_student`
--

DROP TABLE IF EXISTS `supervisor_assigned_student`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `supervisor_assigned_student` (
  `id` int NOT NULL AUTO_INCREMENT,
  `student_id` int NOT NULL,
  `supervisor_id_or_hod_id` int NOT NULL,
  PRIMARY KEY (`id`),
  KEY `fk_supervisor_assigned_student_lab_user1_idx` (`student_id`),
  KEY `fk_supervisor_assigned_student_lab_user2_idx` (`supervisor_id_or_hod_id`),
  CONSTRAINT `fk_supervisor_assigned_student_lab_user1` FOREIGN KEY (`student_id`) REFERENCES `lab_user` (`id`),
  CONSTRAINT `fk_supervisor_assigned_student_lab_user2` FOREIGN KEY (`supervisor_id_or_hod_id`) REFERENCES `lab_user` (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=25 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `supervisor_assigned_student`
--

LOCK TABLES `supervisor_assigned_student` WRITE;
/*!40000 ALTER TABLE `supervisor_assigned_student` DISABLE KEYS */;
INSERT INTO `supervisor_assigned_student` VALUES (24,21,18);
/*!40000 ALTER TABLE `supervisor_assigned_student` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `user_session`
--

DROP TABLE IF EXISTS `user_session`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `user_session` (
  `id` int NOT NULL AUTO_INCREMENT,
  `created_at` datetime DEFAULT NULL,
  `lab_user_id` int NOT NULL,
  PRIMARY KEY (`id`),
  KEY `fk_user_session_lab_user1_idx` (`lab_user_id`),
  CONSTRAINT `fk_user_session_lab_user1` FOREIGN KEY (`lab_user_id`) REFERENCES `lab_user` (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=681 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `user_session`
--

LOCK TABLES `user_session` WRITE;
/*!40000 ALTER TABLE `user_session` DISABLE KEYS */;
INSERT INTO `user_session` VALUES (652,'2026-03-23 09:06:48',1),(653,'2026-03-23 10:57:10',1),(654,'2026-03-23 11:01:23',1),(655,'2026-03-23 14:52:38',1),(656,'2026-03-23 14:57:31',1),(657,'2026-03-23 14:57:51',19),(658,'2026-03-23 15:06:26',18),(659,'2026-03-23 15:06:56',21),(660,'2026-03-23 15:07:31',18),(661,'2026-03-23 15:09:17',19),(662,'2026-03-23 15:12:41',1),(663,'2026-03-23 15:17:09',1),(664,'2026-03-23 15:19:38',19),(665,'2026-03-23 15:28:44',18),(666,'2026-03-23 15:29:07',19),(667,'2026-03-23 15:29:42',1),(668,'2026-03-23 17:36:55',1),(669,'2026-03-23 23:00:01',18),(670,'2026-03-23 23:37:30',19),(671,'2026-03-23 23:44:15',1),(672,'2026-03-24 06:56:32',1),(673,'2026-03-24 07:10:53',19),(674,'2026-03-24 07:26:00',1),(675,'2026-03-24 07:31:43',21),(676,'2026-03-24 07:32:41',18),(677,'2026-03-24 07:34:35',1),(678,'2026-03-24 07:34:55',20),(679,'2026-03-24 07:37:57',18),(680,'2026-03-24 07:38:25',20);
/*!40000 ALTER TABLE `user_session` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Dumping events for database 'mdb'
--

--
-- Dumping routines for database 'mdb'
--
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on 2026-03-24  9:26:09
